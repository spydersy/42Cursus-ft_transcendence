# Typescript Pong

A Pen created on CodePen.io. Original URL: [https://codepen.io/salammia/pen/yjOgyB](https://codepen.io/salammia/pen/yjOgyB).

Pong created with Typescript and the Canvas API